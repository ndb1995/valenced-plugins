(function() {
    var $lazy = function $lazy(resolve) {
        return new Proxy({}, {
            get: function get(_, key) {
                return resolve()[key];
            },
            has: function has(_, key) {
                return key in resolve();
            }
        });
    };
    var $ext0 = $lazy(function() {
        return valenced.modules.finders;
    });
    var $ext1 = $lazy(function() {
        return valenced.modules.finders.filters;
    });
    var $ext2 = $lazy(function() {
        return valenced.patcher;
    });
    var $ext3 = $lazy(function() {
        return valenced.discord.flux;
    });
    var $ext4 = $lazy(function() {
        return valenced.externals.ReactNativeClipboard;
    });
    var $ext5 = $lazy(function() {
        return valenced.discord.actions;
    });
    var $ext6 = $lazy(function() {
        return valenced.components;
    });
    var $ext7 = $lazy(function() {
        return valenced.discord.design;
    });
    var $ext8 = $lazy(function() {
        return valenced.react.React;
    });
    var $ext9 = $lazy(function() {
        return valenced.react.ReactNative;
    });
    var $ext10 = $lazy(function() {
        return valenced.react.ReactJSXRuntime;
    });
    return function(exports, _valenced_modules_finders, _valenced_modules_finders_filters, _valenced_patcher, _valenced_discord_flux, _valenced_externals_react_native_clipboard, _valenced_discord_actions, _valenced_components, _valenced_discord_design, react, react_native, react_jsx_runtime) {
        Object.defineProperty(exports, Symbol.toStringTag, {
            value: "Module"
        });
        // plugins/catbox-upload/js/settings.ts
        var DEFAULTS = {
            host: "catbox",
            litterboxTime: "72h",
            limitMb: 10,
            alwaysUpload: false,
            fallback: true,
            afterUpload: "send",
            maskedLinks: true,
            userhash: "",
            command: true,
            proxyUrl: "",
            proxyLinks: false
        };
        var storage;
        function bindStorage(value) {
            storage = value;
        }
        function readSettings() {
            return {
                ...DEFAULTS,
                ...storage?.cache
            };
        }
        // plugins/catbox-upload/js/utils.ts
        var MiB = 1048576;
        var log = console;
        function setLog(value) {
            log = value ?? console;
        }
        function toast(key, text, variant = "default") {
            try {
                _valenced_discord_actions.ToastActionCreators.open(key, {
                    text,
                    variant
                });
            } catch  {
                try {
                    _valenced_discord_actions.ToastActionCreators.open({
                        key,
                        content: text
                    });
                } catch (e) {
                    log.warn("Could not show toast", e);
                }
            }
        }
        function formatBytes(bytes, decimals = 2) {
            if (!+bytes) return "0 Bytes";
            var sizes = [
                "Bytes",
                "KB",
                "MB",
                "GB",
                "TB"
            ];
            var i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), sizes.length - 1);
            return `${Number.parseFloat((bytes / 1024 ** i).toFixed(decimals))} ${sizes[i]}`;
        }
        function roundDuration(hours) {
            if (hours <= 3) return 1;
            if (hours <= 15) return 12;
            if (hours <= 27) return 24;
            return 72;
        }
        /** Parses `12`, `12h`, `3d` and similar into hours. */ function parseHours(input) {
            var match = /^(\d+(?:\.\d+)?)\s*(h|hrs?|hours?|d|days?)?$/i.exec(String(input ?? "").trim());
            if (!match) return;
            var hours = Number(match[1]) * (match[2]?.[0]?.toLowerCase() === "d" ? 24 : 1);
            return hours > 0 && Number.isFinite(hours) ? hours : void 0;
        }
        function errorMessage(e) {
            return e instanceof Error ? e.message : String(e);
        }
        /** Makes response bodies (sometimes whole HTML pages) short enough for a toast. */ function snippet(text, max = 160) {
            var flat = String(text ?? "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
            return flat.length > max ? `${flat.slice(0, max - 1)}…` : flat;
        }
        /** Splits text on line boundaries into chunks of at most `max` characters. */ function chunkLines(text, max = 2e3) {
            var pieces = [];
            for (var line of text.split("\n"))if (line.length <= max) pieces.push(line);
            else for(var i = 0; i < line.length; i += max)pieces.push(line.slice(i, i + max));
            var chunks = [];
            var current;
            for (var piece of pieces)if (current === void 0) current = piece;
            else if (current.length + 1 + piece.length <= max) current += `\n${piece}`;
            else {
                chunks.push(current);
                current = piece;
            }
            if (current) chunks.push(current);
            return chunks.filter(function(chunk) {
                return chunk.trim();
            });
        }
        // plugins/catbox-upload/js/hosts.ts
        var HOSTS = {
            catbox: {
                name: "Catbox",
                maxBytes: 200 * MiB
            },
            litterbox: {
                name: "Litterbox",
                maxBytes: 1024 * MiB
            },
            pomf: {
                name: "Pomf",
                maxBytes: 1024 * MiB
            }
        };
        var HOST_ORDER = [
            "catbox",
            "litterbox",
            "pomf"
        ];
        var MAX_BYTES = Math.max(...HOST_ORDER.map(function(host) {
            return HOSTS[host].maxBytes;
        }));
        /** Preferred host first, then the rest in default order, skipping any the file is too big for. */ function planHosts(size, preferred, fallback) {
            var plan = [
                preferred,
                ...HOST_ORDER.filter(function(host) {
                    return host !== preferred;
                })
            ].filter(function(host) {
                return size <= HOSTS[host].maxBytes;
            });
            return fallback ? plan : plan.slice(0, 1);
        }
        function normalizeProxyUrl(url) {
            return url.trim().replace(/\/+$/, "");
        }
        function uploadTo(host, file, options) {
            var proxyUrl = normalizeProxyUrl(options.proxyUrl);
            if (proxyUrl) return uploadViaProxy(proxyUrl, host, file, options);
            switch(host){
                case "catbox":
                    return uploadToCatbox(file, options);
                case "litterbox":
                    return uploadToLitterbox(file, options);
                case "pomf":
                    return uploadToPomf(file, options);
            }
        }
        async function uploadToCatbox(file, options) {
            var form = new FormData();
            form.append("reqtype", "fileupload");
            var userhash = options.userhash.trim();
            if (userhash) form.append("userhash", userhash);
            form.append("fileToUpload", file);
            return expectUrl(await post("https://catbox.moe/user/api.php", form, options.onProgress));
        }
        async function uploadToLitterbox(file, options) {
            var form = new FormData();
            form.append("reqtype", "fileupload");
            form.append("time", options.time);
            form.append("fileToUpload", file);
            return expectUrl(await post("https://litterbox.catbox.moe/resources/internals/api.php", form, options.onProgress));
        }
        async function uploadToPomf(file, options) {
            var form = new FormData();
            form.append("files[]", file);
            var json = parseJson(await post("https://pomf.lain.la/upload.php", form, options.onProgress));
            if (!json?.success) throw new Error(String(json?.description ?? json?.error ?? "Upload rejected"));
            var url = json.files?.[0]?.url;
            if (typeof url !== "string" || !url) throw new Error("No URL in response");
            return url;
        }
        async function uploadViaProxy(proxyUrl, host, file, options) {
            var form = new FormData();
            form.append("destination", host);
            form.append("time", options.time);
            var userhash = options.userhash.trim();
            if (userhash) form.append("userhash", userhash);
            form.append("file", file);
            var json = parseJson(await post(`${proxyUrl}/direct`, form, options.onProgress));
            var url = json?.url;
            if (typeof url !== "string" || !url) throw new Error(String(json?.error ?? "No URL in proxy response"));
            if (!options.proxyLinks) return url;
            var fileName = url.split(/[?#]/)[0].split("/").pop();
            return fileName ? `${proxyUrl}/${host}/${fileName}` : url;
        }
        function expectUrl(text) {
            var url = text.trim();
            if (!url.startsWith("https://")) throw new Error(snippet(url) || "Empty response");
            return url;
        }
        function parseJson(text) {
            try {
                return JSON.parse(text);
            } catch  {
                throw new Error(`Unexpected response: ${snippet(text) || "empty"}`);
            }
        }
        function post(url, body, onProgress) {
            return new Promise(function(resolve, reject) {
                var xhr = new XMLHttpRequest();
                xhr.open("POST", url);
                xhr.onload = function() {
                    var text = String(xhr.responseText ?? "");
                    if (xhr.status >= 200 && xhr.status < 300) resolve(text);
                    else reject(/* @__PURE__ */ new Error(`HTTP ${xhr.status}${text ? `: ${snippet(text)}` : ""}`));
                };
                xhr.onerror = function() {
                    return reject(/* @__PURE__ */ new Error(`Network error while contacting ${hostOf(url)}`));
                };
                xhr.ontimeout = function() {
                    return reject(/* @__PURE__ */ new Error(`Timed out while contacting ${hostOf(url)}`));
                };
                if (onProgress && xhr.upload) xhr.upload.onprogress = function(event) {
                    if (event.lengthComputable && event.total > 0) onProgress(event.loaded / event.total);
                };
                xhr.send(body);
            });
        }
        function hostOf(url) {
            return url.replace(/^[a-z]+:\/\//i, "").split("/")[0];
        }
        // plugins/catbox-upload/js/uploader.ts
        var FLUSH_DELAY = 750;
        var MAX_MESSAGE_LENGTH = 2e3;
        var batches = /* @__PURE__ */ new Map();
        var queuedInserts = /* @__PURE__ */ new Map();
        var nextOverride;
        var MessageActions;
        var sendingOwnMessage = false;
        var uploadCount = 0;
        function setNextUploadOverride(override) {
            nextOverride = override;
        }
        function resetUploaderState() {
            for (var batch of batches.values())if (batch.timer !== void 0) clearTimeout(batch.timer);
            batches.clear();
            queuedInserts.clear();
            nextOverride = void 0;
            MessageActions = void 0;
            sendingOwnMessage = false;
            uploadCount = 0;
        }
        function patchUploader(cleanup) {
            cleanup((0, _valenced_modules_finders.getModules)((0, _valenced_modules_finders_filters.withProps)("CloudUpload"), function(mod) {
                var proto = mod?.CloudUpload?.prototype;
                if (typeof proto?.reactNativeCompressAndExtractData !== "function") {
                    log.warn("CloudUpload.prototype.reactNativeCompressAndExtractData not found, uploads are left alone");
                    return;
                }
                cleanup((0, _valenced_patcher.instead)(proto, "reactNativeCompressAndExtractData", function(args, original) {
                    var job;
                    try {
                        job = prepareJob(this);
                    } catch (e) {
                        log.error("Could not inspect upload, passing it to Discord", e);
                    }
                    return job ? runJob(this, job) : original.apply(this, args);
                }));
            }));
        }
        function patchMessageSender(cleanup) {
            cleanup((0, _valenced_modules_finders.getModules)((0, _valenced_modules_finders_filters.withProps)("sendMessage", "editMessage"), function(mod) {
                MessageActions = mod;
                cleanup((0, _valenced_patcher.before)(mod, "sendMessage", function(args) {
                    var [channelId, message] = args;
                    var queued = queuedInserts.get(channelId);
                    if (sendingOwnMessage || queued === void 0 || !message || typeof message !== "object") return args;
                    queuedInserts.delete(channelId);
                    message.content = message.content ? `${message.content}\n${queued}` : queued;
                    return args;
                }));
            }));
        }
        /** Returns undefined when Discord should handle the upload itself. */ function prepareJob(upload) {
            var settings = readSettings();
            var size = Number(upload.preCompressionSize ?? upload.currentSize ?? 0) || 0;
            if (!settings.alwaysUpload && size <= (Number(settings.limitMb) || 10) * 1048576) return;
            var uri = upload.item?.originalUri ?? upload.item?.uri ?? upload.uri ?? upload.fileUri ?? upload.path ?? upload.sourceURL;
            if (!uri) return;
            var channelId = upload.channelId ?? selectedChannelId();
            if (!channelId) return;
            var batch = batches.get(channelId);
            if (!planHosts(size, (batch?.pending ? batch.override : nextOverride ?? batch?.override)?.host ?? settings.host, settings.fallback).length) {
                toast("catbox-upload-too-large", `${formatBytes(size)} is too large for any host (max ${formatBytes(MAX_BYTES)})`, "critical");
                return;
            }
            if (!batch) batches.set(channelId, batch = {
                pending: 0,
                links: [],
                failed: 0
            });
            if (batch.timer !== void 0) {
                clearTimeout(batch.timer);
                batch.timer = void 0;
            }
            if (batch.pending++ === 0) {
                batch.override = nextOverride ?? batch.override;
                nextOverride = void 0;
            }
            upload.preCompressionSize = 1337;
            return {
                batch,
                channelId,
                size,
                file: {
                    uri: String(uri),
                    name: String(upload.filename ?? upload.item?.filename ?? "upload"),
                    type: String(upload.mimeType ?? upload.item?.mimeType ?? "application/octet-stream")
                },
                plan: planHosts(size, batch.override?.host ?? settings.host, settings.fallback),
                time: batch.override?.duration ?? settings.litterboxTime,
                settings
            };
        }
        async function runJob(upload, job) {
            var { batch, channelId, settings } = job;
            var toastKey = `catbox-upload-${++uploadCount}`;
            var link;
            var lastError;
            for (var host of job.plan)try {
                link = await uploadWithProgress(host, job, toastKey);
                break;
            } catch (e) {
                lastError = `${HOSTS[host].name}: ${errorMessage(e)}`;
                log.warn(`Upload of ${job.file.name} to ${HOSTS[host].name} failed`, e);
            }
            try {
                upload.setStatus?.("CANCELED");
            } catch (e) {
                log.warn("Could not cancel the Discord upload", e);
            }
            if (batches.get(channelId) !== batch) {
                if (link) log.log(`Uploaded ${job.file.name} after the plugin stopped: ${link}`);
                return null;
            }
            if (link) batch.links.push(formatLink(job.file.name, link, settings.maskedLinks));
            else {
                batch.failed++;
                batch.lastError = lastError ?? "no host available";
            }
            if (--batch.pending === 0) batch.timer = setTimeout(function() {
                return flush(channelId);
            }, FLUSH_DELAY);
            return null;
        }
        function uploadWithProgress(host, job, toastKey) {
            var { settings } = job;
            var label = `Uploading ${job.size ? `${formatBytes(job.size)} ` : ""}to ${HOSTS[host].name}…`;
            var step = 0;
            toast(toastKey, label);
            return uploadTo(host, job.file, {
                time: job.time,
                userhash: settings.userhash,
                proxyUrl: settings.proxyUrl,
                proxyLinks: settings.proxyLinks,
                onProgress (fraction) {
                    var next = Math.min(4, Math.floor(fraction * 4));
                    if (next <= step) return;
                    step = next;
                    toast(toastKey, `${label} ${next * 25}%`);
                }
            });
        }
        function formatLink(name, url, masked) {
            if (!masked) return url;
            return `[${name.replace(/[[\]]/g, "") || "file"}](${url})`;
        }
        function flush(channelId) {
            var batch = batches.get(channelId);
            if (!batch || batch.pending > 0) return;
            batches.delete(channelId);
            if (!batch.links.length) {
                toast("catbox-upload-result", `Upload failed: ${batch.lastError ?? "unknown error"}`, "critical");
                return;
            }
            var text = [
                takeFailedMessageText(channelId),
                ...batch.links
            ].filter(Boolean).join("\n");
            var failedNote = batch.failed ? ` ${batch.failed} file(s) failed: ${batch.lastError}` : "";
            deliver(channelId, text, readSettings().afterUpload, batch.links.length > 1).then(function(outcome) {
                return toast("catbox-upload-result", `${outcome}${failedNote}`, failedNote ? "critical" : "success");
            }, function(e) {
                log.error("Could not deliver the upload link", text, e);
                toast("catbox-upload-result", `Uploaded, but the link could not be delivered: ${errorMessage(e)}`, "critical");
            });
        }
        /** Deletes Discord's failed copies of the message and returns their text to go with the links. */ function takeFailedMessageText(channelId) {
            var contents = [];
            try {
                var PendingMessages = (0, _valenced_modules_finders.lookupModule)((0, _valenced_modules_finders_filters.withProps)("getPendingMessages", "deletePendingMessage"))[0];
                var pending = PendingMessages?.getPendingMessages?.(channelId);
                if (!pending) return "";
                var entries = pending instanceof Map ? pending : Object.entries(pending);
                for (var [id, message] of entries){
                    if (message?.state !== "FAILED") continue;
                    var content = typeof message.content === "string" ? message.content.trim() : "";
                    if (content && !contents.includes(content)) contents.push(content);
                    PendingMessages.deletePendingMessage(channelId, id);
                }
            } catch (e) {
                log.warn("Could not clean up failed messages", e);
            }
            return contents.join("\n");
        }
        async function deliver(channelId, text, mode, plural) {
            var noun = plural ? "Links" : "Link";
            if (mode === "copy") {
                _valenced_externals_react_native_clipboard.Clipboard.setString(text);
                return `${noun} copied to clipboard.`;
            }
            if (mode === "insert") {
                if (!MessageActions) {
                    _valenced_externals_react_native_clipboard.Clipboard.setString(text);
                    return `Couldn't hook message sending, ${noun.toLowerCase()} copied to clipboard instead.`;
                }
                var queued = queuedInserts.get(channelId);
                queuedInserts.set(channelId, queued ? `${queued}\n${text}` : text);
                return `${noun} will be added to your next message.`;
            }
            var actions = getMessageActions();
            if (typeof actions?.sendMessage !== "function") {
                _valenced_externals_react_native_clipboard.Clipboard.setString(text);
                return `Couldn't send the ${noun.toLowerCase()}, copied to clipboard instead.`;
            }
            try {
                for (var content of chunkLines(text, MAX_MESSAGE_LENGTH)){
                    var result = void 0;
                    sendingOwnMessage = true;
                    try {
                        result = actions.sendMessage(channelId, {
                            content,
                            tts: false,
                            invalidEmojis: [],
                            validNonShortcutEmojis: []
                        });
                    } finally{
                        sendingOwnMessage = false;
                    }
                    await result;
                }
                return `${noun} sent.`;
            } catch (e) {
                log.error("Sending the link failed", e);
                _valenced_externals_react_native_clipboard.Clipboard.setString(text);
                return `Couldn't send the ${noun.toLowerCase()}, copied to clipboard instead.`;
            }
        }
        function getMessageActions() {
            return MessageActions ?? (0, _valenced_modules_finders.lookupModule)((0, _valenced_modules_finders_filters.withProps)("sendMessage", "editMessage"))[0] ?? (0, _valenced_modules_finders.lookupModule)((0, _valenced_modules_finders_filters.withProps)("sendMessage"))[0];
        }
        function selectedChannelId() {
            try {
                return _valenced_discord_flux.Stores.SelectedChannelStore?.getChannelId?.();
            } catch  {
                return;
            }
        }
        // plugins/catbox-upload/js/command.ts
        var CHAT_INPUT = 1;
        var FALLBACK_ID = "-31337";
        var DESCRIPTION = "Send your next upload to Litterbox (temporary hosting)";
        var DURATION_DESCRIPTION = "Hours to keep the file: 1, 12, 24 or 72";
        function patchCommands(cleanup) {
            cleanup((0, _valenced_modules_finders.getModules)((0, _valenced_modules_finders_filters.withProps)("getBuiltInCommands"), function(mod) {
                if (typeof mod?.getBuiltInCommands !== "function") return;
                var command;
                cleanup((0, _valenced_patcher.instead)(mod, "getBuiltInCommands", function(args, original) {
                    var _this = this;
                    var res = original.apply(this, args);
                    try {
                        if (!readSettings().command || !Array.isArray(res) || !wantsChatCommands(args[0])) return res;
                        command ??= createCommand(nextFreeId(function() {
                            return original.call(_this, CHAT_INPUT, true, false);
                        }));
                        return [
                            ...res,
                            command
                        ];
                    } catch (e) {
                        log.warn("Could not add the /litterbox command", e);
                        return res;
                    }
                }));
            }));
        }
        function wantsChatCommands(type) {
            return type === CHAT_INPUT || Array.isArray(type) && type.includes(CHAT_INPUT);
        }
        /** One below the lowest built-in id, so it can't collide with Discord's commands. */ function nextFreeId(getCommands) {
            try {
                var commands = getCommands();
                var ids = Array.isArray(commands) ? commands.map(function(command) {
                    return Number(command?.id);
                }).filter(function(id) {
                    return Number.isFinite(id);
                }) : [];
                return ids.length ? String(Math.min(...ids) - 1) : FALLBACK_ID;
            } catch  {
                return FALLBACK_ID;
            }
        }
        function createCommand(id) {
            return {
                id,
                applicationId: "-1",
                type: CHAT_INPUT,
                inputType: 0,
                name: "litterbox",
                displayName: "litterbox",
                untranslatedName: "litterbox",
                description: DESCRIPTION,
                displayDescription: DESCRIPTION,
                untranslatedDescription: DESCRIPTION,
                options: [
                    {
                        name: "duration",
                        displayName: "duration",
                        description: DURATION_DESCRIPTION,
                        displayDescription: DURATION_DESCRIPTION,
                        type: 3,
                        required: false
                    }
                ],
                execute (args) {
                    try {
                        var rounded = roundDuration(parseHours(Array.isArray(args) ? args.find(function(arg) {
                            return arg?.name === "duration";
                        })?.value ?? args[0]?.value : void 0) ?? parseHours(readSettings().litterboxTime) ?? 72);
                        setNextUploadOverride({
                            host: "litterbox",
                            duration: `${rounded}h`
                        });
                        toast("catbox-upload-command", `Next upload goes to Litterbox for ${rounded}h`, "success");
                    } catch (e) {
                        log.error("/litterbox failed", e);
                    }
                }
            };
        }
        // plugins/catbox-upload/js/SettingsPage.tsx
        function SettingsPage({ api }) {
            var { Stack, TableRadioGroup, TableRadioRow, TableRowGroup, TableSwitchRow } = _valenced_discord_design.Design;
            var settings = {
                ...DEFAULTS,
                ...api.jsonStorage.use()
            };
            var save = function save(value) {
                api.jsonStorage.set(value);
            };
            return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_valenced_components.Page, {
                spacing: 0,
                children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(react_native.ScrollView, {
                    keyboardShouldPersistTaps: "handled",
                    style: {
                        flex: 1
                    },
                    children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(Stack, {
                        spacing: 24,
                        style: {
                            paddingBottom: 32
                        },
                        children: [
                            /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(TableRadioGroup, {
                                title: "Upload to",
                                value: settings.host,
                                onChange: function onChange(host) {
                                    return save({
                                        host
                                    });
                                },
                                children: [
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRadioRow, {
                                        label: "Catbox",
                                        subLabel: "Permanent, up to 200 MB",
                                        value: "catbox"
                                    }),
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRadioRow, {
                                        label: "Litterbox",
                                        subLabel: "Temporary, up to 1 GB",
                                        value: "litterbox"
                                    }),
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRadioRow, {
                                        label: "Pomf",
                                        subLabel: "pomf.lain.la, up to 1 GB",
                                        value: "pomf"
                                    })
                                ]
                            }),
                            /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(TableRadioGroup, {
                                title: "Litterbox expiry",
                                value: settings.litterboxTime,
                                onChange: function onChange(litterboxTime) {
                                    return save({
                                        litterboxTime
                                    });
                                },
                                children: [
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRadioRow, {
                                        label: "1 hour",
                                        value: "1h"
                                    }),
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRadioRow, {
                                        label: "12 hours",
                                        value: "12h"
                                    }),
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRadioRow, {
                                        label: "24 hours",
                                        value: "24h"
                                    }),
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRadioRow, {
                                        label: "3 days",
                                        value: "72h"
                                    })
                                ]
                            }),
                            /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(TableRadioGroup, {
                                title: "Your Discord upload limit",
                                value: String(settings.limitMb),
                                onChange: function onChange(value) {
                                    return save({
                                        limitMb: Number(value)
                                    });
                                },
                                children: [
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRadioRow, {
                                        label: "10 MB",
                                        subLabel: "Free",
                                        value: "10"
                                    }),
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRadioRow, {
                                        label: "50 MB",
                                        subLabel: "Nitro Basic or Level 2 server",
                                        value: "50"
                                    }),
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRadioRow, {
                                        label: "100 MB",
                                        subLabel: "Level 3 server",
                                        value: "100"
                                    }),
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRadioRow, {
                                        label: "500 MB",
                                        subLabel: "Nitro",
                                        value: "500"
                                    })
                                ]
                            }),
                            /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(TableRadioGroup, {
                                title: "After uploading",
                                value: settings.afterUpload,
                                onChange: function onChange(afterUpload) {
                                    return save({
                                        afterUpload
                                    });
                                },
                                children: [
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRadioRow, {
                                        label: "Send the link in chat",
                                        value: "send"
                                    }),
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRadioRow, {
                                        label: "Add the link to my next message",
                                        value: "insert"
                                    }),
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRadioRow, {
                                        label: "Copy the link",
                                        value: "copy"
                                    })
                                ]
                            }),
                            /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(TableRowGroup, {
                                title: "Options",
                                children: [
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableSwitchRow, {
                                        label: "Upload every file",
                                        subLabel: "Also reroute files under your limit",
                                        value: settings.alwaysUpload,
                                        onValueChange: function onValueChange(alwaysUpload) {
                                            return save({
                                                alwaysUpload
                                            });
                                        }
                                    }),
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableSwitchRow, {
                                        label: "Try other hosts if one fails",
                                        value: settings.fallback,
                                        onValueChange: function onValueChange(fallback) {
                                            return save({
                                                fallback
                                            });
                                        }
                                    }),
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableSwitchRow, {
                                        label: "Show file name instead of URL",
                                        value: settings.maskedLinks,
                                        onValueChange: function onValueChange(maskedLinks) {
                                            return save({
                                                maskedLinks
                                            });
                                        }
                                    }),
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableSwitchRow, {
                                        label: "/litterbox command",
                                        value: settings.command,
                                        onValueChange: function onValueChange(command) {
                                            return save({
                                                command
                                            });
                                        }
                                    })
                                ]
                            }),
                            /* @__PURE__ */ (0, react_jsx_runtime.jsx)(SettingTextInput, {
                                label: "Catbox userhash",
                                placeholder: "Optional: links uploads to your catbox.moe account",
                                secureTextEntry: true,
                                value: settings.userhash,
                                normalize: function normalize(text) {
                                    return text.trim();
                                },
                                onSave: function onSave(userhash) {
                                    return save({
                                        userhash
                                    });
                                }
                            }),
                            /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(Stack, {
                                spacing: 12,
                                children: [
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableRowGroup, {
                                        title: "Proxy (advanced)",
                                        children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TableSwitchRow, {
                                            label: "Rewrite links through proxy",
                                            disabled: !settings.proxyUrl,
                                            value: settings.proxyLinks,
                                            onValueChange: function onValueChange(proxyLinks) {
                                                return save({
                                                    proxyLinks
                                                });
                                            }
                                        })
                                    }),
                                    /* @__PURE__ */ (0, react_jsx_runtime.jsx)(SettingTextInput, {
                                        label: "Proxy URL",
                                        placeholder: "https://your-proxy.example",
                                        value: settings.proxyUrl,
                                        normalize: normalizeProxyUrl,
                                        onSave: function onSave(proxyUrl) {
                                            return save({
                                                proxyUrl
                                            });
                                        }
                                    })
                                ]
                            })
                        ]
                    })
                })
            });
        }
        function SettingTextInput({ value, normalize, onSave, ...props }) {
            var { TextInput } = _valenced_discord_design.Design;
            var [draft, setDraft] = (0, react.useState)(value);
            return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TextInput, {
                ...props,
                size: "md",
                value: draft,
                onChange: function onChange(text) {
                    setDraft(text);
                    onSave(text);
                },
                onBlur: function onBlur() {
                    var normalized = normalize ? normalize(draft) : draft;
                    if (normalized === draft) return;
                    setDraft(normalized);
                    onSave(normalized);
                }
            });
        }
        exports.default = plugin({
            jsonStorage: {
                default: DEFAULTS,
                load: true
            },
            start ({ cleanup, jsonStorage, logger }) {
                bindStorage(jsonStorage);
                setLog(logger);
                cleanup(function() {
                    resetUploaderState();
                    bindStorage(void 0);
                    setLog(void 0);
                });
                patchMessageSender(cleanup);
                patchUploader(cleanup);
                patchCommands(cleanup);
            },
            SettingsComponent: SettingsPage
        });
        return exports;
    }({}, $ext0, $ext1, $ext2, $ext3, $ext4, $ext5, $ext6, $ext7, $ext8, $ext9, $ext10);
})();
